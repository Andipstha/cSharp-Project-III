﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LibraryManagementSystem
{
    public partial class ReturnBook : Form
    {
        public ReturnBook()
        {
            InitializeComponent();
        }

        private void btnSearchStudent_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source = .\SQLEXPRESS;
                                                Initial Catalog=LibraryDBS;
                                                Integrated Security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;

            cmd.CommandText = "select * from IRBook where std_enroll = '" + txtEnterEnroll.Text + "' and book_return_date IS NULL";
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);

            if (ds.Tables[0].Rows.Count != 0)
            {
                dataGridView1.DataSource = ds.Tables[0];
            }
            else
            {
                MessageBox.Show("Invalid ID or No Book Issued", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ReturnBook_Load(object sender, EventArgs e)
        {
            panel2.Visible = false;
            txtEnterEnroll.Clear();
        }

        String bName;
        String bDate;
        Int64 rowid;

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            panel2.Visible = true;
            if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value !=null)
            {
                rowid = Int64.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                bName = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
                bDate = dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();

            }
            txtBookName.Text = bName;
            txtBookIssueDate.Text = bDate;

            //fine 

            DateTime FirstDate = Convert.ToDateTime(txtBookIssueDate.Text.ToString());
            DateTime SecondDate = dateTimePicker1.Value;


            TimeSpan ts = SecondDate - FirstDate;

            int differenceInDays = ts.Days;
            if (differenceInDays > 30)
            {
                int fine = (differenceInDays - 30) * 2;
                textBox1.Text = fine.ToString();
            }
            else
            {
                int fine = 0;
                textBox1.Text = fine.ToString();
            }
            //int fine = differenceInDays * 2;

            textBox2.Text = differenceInDays.ToString();


            Console.WriteLine("Difference in days: {0}", differenceInDays);

            //fine end

        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            
            ////fine 

            //DataGridViewRow data = dataGridView1.CurrentRow;

            ////DateTime FirstDate = Convert.ToDateTime(data.Cells["book_issue_date"].Value.ToString());
            ////DateTime SecondDate = data.Cells["book_return_date"].Value.ToString() != "" ? Convert.ToDateTime(data.Cells["book_return_date"].Value.ToString()) : DateTime.Now;

            //DateTime FirstDate = Convert.ToDateTime(txtBookIssueDate.Text.ToString());
            //DateTime SecondDate = dateTimePicker1.Value;
 

            //TimeSpan ts = SecondDate - FirstDate;

            //int differenceInDays = ts.Days;
            //if (differenceInDays > 30)
            //{
            //    int fine = (differenceInDays - 30) * 2;
            //    textBox1.Text = fine.ToString();
            //}
            //else
            //{
            //    int fine = 0;
            //    textBox1.Text = fine.ToString();
            //}
            ////int fine = differenceInDays * 2;

            //textBox2.Text = differenceInDays.ToString();


            //Console.WriteLine("Difference in days: {0}", differenceInDays);

            ////fine end

            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source = .\SQLEXPRESS;
                                                Initial Catalog=LibraryDBS;
                                                Integrated Security=True";
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();

            cmd.CommandText = "update IRBook set book_return_date = '"+ dateTimePicker1.Text +"', std_fine = '"+ textBox1.Text + "' where std_enroll = '"+ txtEnterEnroll.Text +"' and id = "+ rowid +" ";
            cmd.ExecuteNonQuery();



            //Increase reutrn book
            SqlCommand cmd1 = new SqlCommand();
            cmd1.Connection = con;
            cmd1.CommandText = "update NewBook set bQuan = bQuan+1 where bname =  '" + bName + "'  ";
            cmd1.ExecuteNonQuery();


            con.Close();

            MessageBox.Show("Returned Succesful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ReturnBook_Load(this, null); //this will reload the form
        }

        private void txtEnterEnroll_TextChanged(object sender, EventArgs e)
        {
            if(txtEnterEnroll.Text == "")
            {
                panel2.Visible = false;
                dataGridView1.DataSource = null;
            }
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtEnterEnroll.Clear();

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            panel2.Visible = false;
        }

    }
}
